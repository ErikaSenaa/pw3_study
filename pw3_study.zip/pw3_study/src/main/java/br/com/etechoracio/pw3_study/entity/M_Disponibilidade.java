package br.com.etechoracio.pw3_study.entity;
//Erika Sena e Jeniffer Soares
import jakarta.persistence.*;

public class M_Disponibilidade {
    @Id
    @Column(name = "ID_MONITOR")
    private Long id;
    @Id
    @Column(name = "ID_DISCIPLINA")
    private Long ids;
}
