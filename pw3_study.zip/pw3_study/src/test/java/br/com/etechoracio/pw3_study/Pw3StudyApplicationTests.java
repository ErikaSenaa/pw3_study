package br.com.etechoracio.pw3_study;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pw3StudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
